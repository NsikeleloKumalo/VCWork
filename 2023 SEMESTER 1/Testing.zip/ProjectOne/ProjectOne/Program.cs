﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectOne
{
    class Program
    {
        static void Main(string[] args)
        {
            //no sout --> system.out.print
            //replaced with Coonsole.Write
            Console.WriteLine("Testing program one");//CW tab tab helps you create a shortcut
            Console.ReadLine();//Keeps the console open

            //Write vs writeline
            Console.Write("......Output placement");
            Console.WriteLine("...1...2....3");
            Console.ReadLine();//Keeps the console open
        }
    }
}
