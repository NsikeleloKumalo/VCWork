﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesignWitrhClasses
{
    class Values
    {//shorcut prop tab tab 
        public int IngredQnty { get; set; }

        public string IngredName { get; set; }

        public string IngredDesc { get; set; }

        public int Scaling { get; set; }
    }
}
