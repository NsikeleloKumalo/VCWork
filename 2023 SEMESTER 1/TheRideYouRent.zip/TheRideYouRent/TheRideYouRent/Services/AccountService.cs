﻿using TheRideYouRent.Models;

namespace TheRideYouRent.Services
{
    public interface AccountService
    {
        public Account Login(string username, string password);
    }
}
